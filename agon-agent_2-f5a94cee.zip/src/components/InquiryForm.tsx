import { useEffect, useRef, useState } from 'react'
import type { FormEvent } from 'react'
import { ArrowRight, Check, Download, GraduationCap, Landmark, LockKeyhole, Mail, Phone, RotateCcw, Send, Upload, UserRound } from 'lucide-react'
import { degreePrograms, downloadInquiry, emptyForm, FILE_ACCEPT, formatDate, registrationDetails, saveInquiry, semesterOptions, validate } from '../lib/inquiries'
import type { FieldErrors, FieldName, FileField, FormValues, Inquiry, TextField } from '../lib/inquiries'

function FieldLabel({ name, children }: { name: FieldName; children: string }) {
  return <label htmlFor={name}>{children} <span className="required-star" aria-hidden="true">*</span></label>
}

function FieldError({ name, errors }: { name: FieldName; errors: FieldErrors }) {
  return errors[name] ? <p id={`${name}-error`} className="field-error">{errors[name]}</p> : null
}

function DocumentField({ name, label, file, errors, onChange }: { name: FileField; label: string; file: File | null; errors: FieldErrors; onChange: (file: File | null) => void }) {
  return (
    <div className="form-field">
      <FieldLabel name={name}>{label}</FieldLabel>
      <div className={`document-input ${errors[name] ? 'has-error' : ''}`}>
        <Upload size={18} strokeWidth={1.5} aria-hidden="true" />
        <span className="document-caption"><strong>{file?.name || 'Choose a file'}</strong><small id={`${name}-hint`}>JPG, PNG, WebP or PDF · Up to 5 MB</small></span>
        <span className="document-browse">{file ? 'Replace' : 'Browse'}</span>
        <input type="file" id={name} name={name} required accept={FILE_ACCEPT} aria-invalid={Boolean(errors[name])} aria-describedby={`${name}-hint${errors[name] ? ` ${name}-error` : ''}`} onChange={event => onChange(event.target.files?.[0] || null)} />
      </div>
      <FieldError name={name} errors={errors} />
    </div>
  )
}

function PaymentNotice() {
  return (
    <section className="payment-notice" aria-labelledby="payment-notice-title">
      <div className="micro-label">REGISTRATION FEES &amp; PAYMENT</div>
      <h3 id="payment-notice-title">Notice</h3>
      <dl className="fee-list">
        <div><dt>For Students of Public Universities &amp; Colleges:</dt><dd>Rs. 4,310/-</dd></div>
        <div><dt>For Students of Private Universities &amp; Colleges:</dt><dd>Rs. 4,870/-</dd></div>
      </dl>
      <p>Payment will be confirmed by the company within <strong>48 working hours</strong>, followed by a confirmation email.</p>
      <p>Any form of fake or fraudulent payment proof will not be accepted.</p>
      <p>Please transfer your payment to the following account:</p>
      <div className="bank-account">
        <h4><Landmark size={17} strokeWidth={1.5} />Faysal Bank Limited</h4>
        <dl>
          <div><dt>Account Title</dt><dd>FIRST NOBLE STEP (PRIVATE) LIMITED</dd></div>
          <div><dt>Account Number</dt><dd className="account-digits">3291499000005525</dd></div>
          <div><dt>IBAN</dt><dd className="account-digits">PK03FAYS3291499000005525</dd></div>
        </dl>
      </div>
      <p>After transferring, please upload the proof of payment in the field below.</p>
    </section>
  )
}

function Receipt({ inquiry, onAnother }: { inquiry: Inquiry; onAnother: () => void }) {
  const heading = useRef<HTMLHeadingElement>(null)
  useEffect(() => { heading.current?.focus({ preventScroll: true }) }, [])
  return (
    <section className="form-card receipt-card" id="inquiry-form" aria-labelledby="receipt-title">
      <div className="receipt-top"><span className="micro-label">FIRST NOBLE STEP / REGISTRATION RECORD</span><span className="receipt-check"><Check size={19} /></span></div>
      <div className="receipt-content">
        <div className="success-symbol"><Check size={29} strokeWidth={1.65} /></div>
        <div className="micro-label">REGISTRATION SAVED</div>
        <h2 id="receipt-title" ref={heading} tabIndex={-1}>Thanks, {inquiry.name.split(/\s+/)[0]}.</h2>
        <p className="receipt-intro">Your registration and both documents are saved on this device. To review them, open <strong>Privacy note → My registrations</strong>. This local record is not a payment confirmation and has not been sent to the company.</p>
        <div className="receipt-details">
          <div className="receipt-reference"><span>{inquiry.reference}</span><span>{formatDate(inquiry.createdAt)}</span></div>
          <dl>
            {registrationDetails(inquiry).map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}
            <div><dt>University card</dt><dd>{inquiry.universityCard.name}</dd></div>
            <div><dt>Payment proof</dt><dd>{inquiry.paymentProof.name}</dd></div>
          </dl>
        </div>
        <button className="primary-button" onClick={() => downloadInquiry(inquiry)}><Download size={17} />Download a copy</button>
        <button className="new-inquiry-button" onClick={onAnother}><RotateCcw size={15} />Start another registration</button>
      </div>
    </section>
  )
}

export function InquiryForm({ onSaved }: { onSaved: () => void }) {
  const [values, setValues] = useState<FormValues>({ ...emptyForm })
  const [errors, setErrors] = useState<FieldErrors>({})
  const [storageError, setStorageError] = useState('')
  const [saving, setSaving] = useState(false)
  const [receipt, setReceipt] = useState<Inquiry | null>(null)
  const formRef = useRef<HTMLFormElement>(null)
  const submitted = useRef(false)

  function update<K extends keyof FormValues>(field: K, value: FormValues[K]) {
    const next = { ...values, [field]: value }
    setValues(next)
    if (errors[field] || field === 'universityCard' || field === 'paymentProof') setErrors(previous => ({ ...previous, [field]: validate(next)[field] }))
    if (storageError) setStorageError('')
  }
  function onBlur(field: TextField) {
    if (values[field].trim()) setErrors(previous => ({ ...previous, [field]: validate(values)[field] }))
  }
  function fieldProps(name: TextField) {
    return {
      id: name, name, required: true, value: values[name],
      'aria-invalid': Boolean(errors[name]),
      'aria-describedby': errors[name] ? `${name}-error` : undefined,
      onBlur: () => onBlur(name),
    }
  }
  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (submitted.current) return
    const nextErrors = validate(values)
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length) {
      const first = Object.keys(nextErrors)[0]
      formRef.current?.querySelector<HTMLElement>(`[name="${first}"]`)?.focus()
      return
    }
    try {
      submitted.current = true
      setSaving(true)
      const saved = await saveInquiry(values)
      setReceipt(saved)
      setStorageError('')
      onSaved()
    } catch {
      submitted.current = false
      setStorageError('Your registration could not be saved. Please allow site storage or free some space, then try again. Your details and selected documents are still here.')
    } finally {
      setSaving(false)
    }
  }
  function reset() {
    submitted.current = false
    setReceipt(null)
    setValues({ ...emptyForm })
    setErrors({})
    setStorageError('')
    requestAnimationFrame(() => formRef.current?.querySelector<HTMLInputElement>('#name')?.focus())
  }

  if (receipt) return <Receipt inquiry={receipt} onAnother={reset} />
  return (
    <section className="form-card" id="inquiry-form" aria-labelledby="form-heading" tabIndex={-1}>
      <div className="form-heading">
        <div className="form-title-row"><h2 id="form-heading">Registration form</h2><span className="form-number"><span className="tiny-cross">+</span> FORM 01</span></div>
        <p>Enter your contact and academic details below.</p>
      </div>
      <form ref={formRef} noValidate onSubmit={handleSubmit} aria-describedby="required-note">
        <fieldset className="form-fields" disabled={saving}>
          <legend className="sr-only">Student registration details</legend>
          <div className="form-field">
            <FieldLabel name="name">Full name</FieldLabel>
            <div className={`input-wrap ${errors.name ? 'has-error' : ''}`}>
              <UserRound size={18} strokeWidth={1.55} />
              <input {...fieldProps('name')} type="text" autoComplete="name" maxLength={100} placeholder="Your full name" onChange={event => update('name', event.target.value)} />
            </div>
            <FieldError name="name" errors={errors} />
          </div>
          <div className="form-field">
            <FieldLabel name="email">Email address</FieldLabel>
            <div className={`input-wrap ${errors.email ? 'has-error' : ''}`}>
              <Mail size={18} strokeWidth={1.55} />
              <input {...fieldProps('email')} type="email" autoComplete="email" maxLength={254} placeholder="you@example.com" spellCheck={false} autoCapitalize="none" onChange={event => update('email', event.target.value)} />
            </div>
            <FieldError name="email" errors={errors} />
          </div>
          <div className="form-field">
            <FieldLabel name="phone">WhatsApp number</FieldLabel>
            <div className={`input-wrap ${errors.phone ? 'has-error' : ''}`}>
              <Phone size={18} strokeWidth={1.55} />
              <input {...fieldProps('phone')} type="tel" autoComplete="tel" inputMode="tel" maxLength={30} placeholder="Enter WhatsApp number" onChange={event => update('phone', event.target.value)} />
            </div>
            <FieldError name="phone" errors={errors} />
          </div>
          <div className="form-field">
            <FieldLabel name="address">Correspondence address</FieldLabel>
            <p className="field-help" id="address-hint">For certificate and experience letter dispatch.</p>
            <div className={`textarea-wrap ${errors.address ? 'has-error' : ''}`}>
              <textarea {...fieldProps('address')} aria-describedby={`address-hint${errors.address ? ' address-error' : ''}`} autoComplete="street-address" maxLength={2000} placeholder="House / street, area, city and postal code" rows={2} onChange={event => update('address', event.target.value)} />
            </div>
            <FieldError name="address" errors={errors} />
          </div>
          <div className="form-field">
            <FieldLabel name="university">University / college name</FieldLabel>
            <div className={`input-wrap ${errors.university ? 'has-error' : ''}`}>
              <GraduationCap size={18} strokeWidth={1.55} />
              <input {...fieldProps('university')} type="text" autoComplete="organization" maxLength={200} placeholder="Your university or college name" onChange={event => update('university', event.target.value)} />
            </div>
            <FieldError name="university" errors={errors} />
          </div>
          <div className="academic-row">
            <div className="form-field">
              <FieldLabel name="degree">Degree program</FieldLabel>
              <div className={`input-wrap ${errors.degree ? 'has-error' : ''}`}>
                <input {...fieldProps('degree')} list="degree-programs" maxLength={120} placeholder="e.g. Intermediate, ADP, BS" onChange={event => update('degree', event.target.value)} />
                <datalist id="degree-programs">{degreePrograms.map(program => <option key={program} value={program} />)}</datalist>
              </div>
              <FieldError name="degree" errors={errors} />
            </div>
            <div className="form-field">
              <FieldLabel name="semester">Current semester</FieldLabel>
              <div className={`input-wrap ${errors.semester ? 'has-error' : ''}`}>
                <select {...fieldProps('semester')} onChange={event => update('semester', event.target.value)}>
                  <option value="" disabled>Select semester</option>
                  {semesterOptions.map(semester => <option key={semester} value={semester}>Semester {semester}</option>)}
                </select>
              </div>
              <FieldError name="semester" errors={errors} />
            </div>
          </div>
          <DocumentField name="universityCard" label="Upload university card" file={values.universityCard} errors={errors} onChange={file => update('universityCard', file)} />
          <PaymentNotice />
          <DocumentField name="paymentProof" label="Upload payment screenshot / proof" file={values.paymentProof} errors={errors} onChange={file => update('paymentProof', file)} />
        </fieldset>
        {storageError && <div className="storage-error" role="alert">{storageError}</div>}
        <button className="primary-button submit-button" type="submit" disabled={saving}><span><Send size={16} strokeWidth={1.65} />{saving ? 'Saving registration…' : 'Save registration'}</span><ArrowRight size={19} strokeWidth={1.7} /></button>
        <p className="form-privacy"><LockKeyhole size={12} strokeWidth={1.6} /><span>Saved on this device only. Documents are not sent to the company.</span></p>
      </form>
      <span className="sr-only" id="required-note">All fields are required. Attach your university card and payment proof to save your registration.</span>
    </section>
  )
}
